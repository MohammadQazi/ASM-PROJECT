package com.faith.app.model;

import javax.persistence.*;

@Entity
@Table(name = "Login")
public class Login {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer loginId;

	@Enumerated(EnumType.STRING)
	@Column(length = 20)
	private ELogin name;

	public Login() {

	}

	public Login(ELogin name) {
		this.name = name;
	}

	public Integer getLoginId() {
		return loginId;
	}

	public void setLoginId(Integer loginId) {
		this.loginId = loginId;
	}

	public ELogin getName() {
		return name;
	}

	public void setName(ELogin name) {
		this.name = name;
	}
}