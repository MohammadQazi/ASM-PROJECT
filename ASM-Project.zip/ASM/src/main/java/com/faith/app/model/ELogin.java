package com.faith.app.model;

public enum ELogin {
	
    LOGIN_PURCHASE_MANAGER,
    LOGIN_ADMIN
}
